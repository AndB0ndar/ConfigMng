#!/bin/bash

cat "$1" | sed "s/    /\t/g" > "$2"
